package com.example.MyBookShopApp.data.dto;

public class ReviewLikesDto {

    public int value;
    public int reviewid;

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }

    public int getReviewid() {
        return reviewid;
    }

    public void setReviewid(int reviewid) {
        this.reviewid = reviewid;
    }
}
