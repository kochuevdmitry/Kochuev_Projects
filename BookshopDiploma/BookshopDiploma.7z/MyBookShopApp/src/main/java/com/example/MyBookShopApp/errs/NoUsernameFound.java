package com.example.MyBookShopApp.errs;

public class NoUsernameFound extends Exception {
    public NoUsernameFound(String message) {
        super(message);
    }
}
