package com.example.MyBookShopApp.data.enums;

public enum ContactType {
    PHONE,
    EMAIL;
}
