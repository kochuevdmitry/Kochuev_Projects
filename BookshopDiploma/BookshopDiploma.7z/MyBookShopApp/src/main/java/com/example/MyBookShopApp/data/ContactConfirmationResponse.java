package com.example.MyBookShopApp.data;

public class ContactConfirmationResponse {

    private String result;

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }
}
